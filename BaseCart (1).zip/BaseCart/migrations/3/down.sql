
DROP INDEX idx_menu_items_category;
DROP INDEX idx_menu_items_business;
DROP TABLE menu_items;
