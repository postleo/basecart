ALTER TABLE businesses ADD COLUMN custom_link_url TEXT;
ALTER TABLE businesses ADD COLUMN custom_link_text TEXT;