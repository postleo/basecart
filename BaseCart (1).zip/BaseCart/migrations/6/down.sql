ALTER TABLE businesses DROP COLUMN custom_link_text;
ALTER TABLE businesses DROP COLUMN custom_link_url;