
DROP INDEX idx_orders_order_number;
DROP INDEX idx_orders_created_at;
DROP INDEX idx_orders_status;
DROP TABLE orders;
